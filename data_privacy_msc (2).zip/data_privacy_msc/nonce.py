import json
import os
import time
import uuid

# Define the path to the JSON file
NONCE_FILE = "nonce/nonce.json"


def save_nonce_to_file(nonce):
    if not os.path.exists(NONCE_FILE):
        with open(NONCE_FILE, 'w') as file:
            json.dump({}, file)
    with open(NONCE_FILE, 'r') as file:
        nonces = json.load(file)
    nonces[nonce] = {
        "used": False
    }
    with open(NONCE_FILE, 'w') as file:
        json.dump(nonces, file, indent=4)

def is_nonce_valid(nonce):
    if not os.path.exists(NONCE_FILE):
        return False
    with open(NONCE_FILE, 'r') as file:
        nonces = json.load(file)
    nonce_data = nonces.get(nonce)
    if nonce_data is None:
        return False
    if nonce_data.get("used"):
        return False
    return True


def mark_nonce_as_used(nonce):
    if not os.path.exists(NONCE_FILE):
        return
    with open(NONCE_FILE, 'r') as file:
        nonces = json.load(file)
    nonce_data = nonces.get(nonce)
    if nonce_data is None:
        return
    nonces[nonce]["used"] = True
    with open(NONCE_FILE, 'w') as file:
        json.dump(nonces, file, indent=4)


# nonce = str(uuid.uuid4())
# save_nonce_to_file(nonce)
#
# if is_nonce_valid(nonce):
#     print("Nonce is valid")
#     mark_nonce_as_used(nonce)
# else:
#     print("Nonce is invalid or already used")

