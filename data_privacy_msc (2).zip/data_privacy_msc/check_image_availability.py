import base64
import os

import cv2
from skimage.metrics import structural_similarity as ssim

from enums.response_code import ResponseCode
from enums.response_message import ResponseMessage
from models.response import ErrorResponse


def compare_images(image1_path, image2_path):
    img1 = cv2.imread(image1_path, cv2.IMREAD_GRAYSCALE)
    img1 = cv2.resize(img1, (200, 200))
    img2 = cv2.imread(image2_path, cv2.IMREAD_GRAYSCALE)
    img2 = cv2.resize(img2, (200, 200))
    score, _ = ssim(img1, img2, full=True)
    rounded_score = round(score, 2)
    print(rounded_score)
    return rounded_score >= 0.7

def convert_image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
    return encoded_string
# Usage
# result = compare_images('images.png', 'encoded_image_lsb2_2.png')
# print('Images are the same' if result else 'Images are different')

def check_availability():
    dir_list = os.listdir("images")
    print(dir_list)
    for dir in dir_list:
        file_path = f"images/{dir}"
        result = compare_images("uploaded.png", file_path)
        if result:
            raise Exception(
                ErrorResponse(ResponseCode.AVAILABLE_IMAGE,
                              ResponseMessage.AVAILABLE_IMAGE + str("errors")))


# check_availability()