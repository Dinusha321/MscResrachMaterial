SECRETE_KEY = "sskfjfjlkfkehkdkdnhvbdmffkfj"
TOKEN_TIME = 8600
QUESTIONS = {
    "What city were you born in?".lower():"",
    "What is your oldest sibling’s middle name?".lower():"",
    "What is your mother's name?".lower():"",
    "What is the type of your first pet?".lower():"",
    "Who was your childhood hero?".lower():"",
    "What was your childhood ambition?".lower():""
}

ENCRYPTION_KEY = "What is your birthday?".lower()

# print(QUESTIONS.keys())