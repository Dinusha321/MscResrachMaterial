import hashlib
import hmac

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed
from cryptography.hazmat.primitives import serialization
from mnemonic import Mnemonic
from hdwallet import HDWallet
import os
from ecdsa import SigningKey, SECP256k1
from hdwallet.symbols import ETH as SYMBOL
from authentication import generate_token_user
from make_directory import make_node, check_node_availability

BIP32_HARDENED_OFFSET = 0x80000000
ETH_DERIVATION_PATH = "m/44'/60'/0'/0/0"

def derive_private_key(seed: bytes, path: str) -> bytes:
    key = b"Bitcoin seed"
    hmac_result = hmac.new(key, seed, hashlib.sha512).digest()
    master_private_key = hmac_result[:32]
    master_chain_code = hmac_result[32:]
    private_key = master_private_key
    chain_code = master_chain_code
    for level in path.split("/")[1:]:
        hardened = level[-1] == "'"
        index = int(level.rstrip("'")) + (BIP32_HARDENED_OFFSET if hardened else 0)
        data = b"\x00" + private_key + index.to_bytes(4, "big")
        hmac_result = hmac.new(chain_code, data, hashlib.sha512).digest()
        private_key = hmac_result[:32]
        chain_code = hmac_result[32:]
    return private_key

def add_node():
    try:
        mnemo = Mnemonic("english")
        entropy = os.urandom(32)
        mnemonic_phrase = mnemo.to_mnemonic(entropy)
        seed = Mnemonic.to_seed(mnemonic_phrase)
        print(mnemonic_phrase)
        private_key = derive_private_key(seed, ETH_DERIVATION_PATH)
        private_key_bytes = bytes.fromhex(private_key.hex())
        signing_key = SigningKey.from_string(private_key_bytes, curve=SECP256k1)
        public_key_bytes = signing_key.verifying_key.to_string()
        compressed_public_key = b'\x02' + public_key_bytes[:32] if public_key_bytes[
                                                                       -1] % 2 == 0 else b'\x03' + public_key_bytes[:32]
        public_key = compressed_public_key.hex()
        print("Mnemonic Phrase:", mnemonic_phrase)
        print("Derived Private Key:", private_key.hex())
        print("Derived Public Key:", public_key)
        response = {
            "state" : True,
            "private_key": private_key.hex(),
            "phrase":mnemonic_phrase
        }
        make_node(public_key)
        return response
    except Exception as e:
        response = {
            'state': False,
            'error': str(e)
        }
        return response

def log_user_phrase(phrase):
    try:
        seed = Mnemonic.to_seed(phrase)
        private_key = derive_private_key(seed, ETH_DERIVATION_PATH)
        private_key_bytes = bytes.fromhex(private_key.hex())
        signing_key = SigningKey.from_string(private_key_bytes, curve=SECP256k1)
        public_key_bytes = signing_key.verifying_key.to_string()
        compressed_public_key = b'\x02' + public_key_bytes[:32] if public_key_bytes[
                                                                       -1] % 2 == 0 else b'\x03' + public_key_bytes[:32]
        public_key = compressed_public_key.hex()
        print("Mnemonic Phrase:", phrase)
        print("Derived Private Key:", private_key.hex())
        print("Derived Public Key:", public_key)
        response = {
            'state': check_node_availability(public_key),
            'public_key':public_key
        }
        return response
    except Exception as e:
        response = {
            'state': False,
            'error': str(e)
        }
        return response

def log_user_image(private_key):
    try:
        private_key_bytes = bytes.fromhex(private_key)
        signing_key = SigningKey.from_string(private_key_bytes, curve=SECP256k1)
        public_key_bytes = signing_key.verifying_key.to_string()
        compressed_public_key = b'\x02' + public_key_bytes[:32] if public_key_bytes[
                                                                       -1] % 2 == 0 else b'\x03' + public_key_bytes[:32]
        public_key = compressed_public_key.hex()
        print("Public Key (Uncompressed):", public_key)
        response = {
            'state': check_node_availability(public_key),
            'public_key':public_key
        }
        return response
    except Exception as e:
        response = {
            'state': False,
            'error': str(e)
        }
        return response

# private_key_bytes = bytes.fromhex("4144f3ebbeccd7cd0c0ad8380fee7ad32251f235ff6df8b1ef2b0be22d9c314f")
# signing_key = SigningKey.from_string(private_key_bytes, curve=SECP256k1)
# public_key_bytes = signing_key.verifying_key.to_string()
# compressed_public_key = b'\x02' + public_key_bytes[:32] if public_key_bytes[
#                                                                -1] % 2 == 0 else b'\x03' + public_key_bytes[:32]
# public_key = compressed_public_key.hex()
# print("Public Key (Uncompressed):", public_key)
