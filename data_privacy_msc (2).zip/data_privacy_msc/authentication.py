import time
import uuid

import jwt
import env
from enums.response_code import ResponseCode
from enums.response_message import ResponseMessage
from models.response import ErrorResponse
from nonce import save_nonce_to_file, is_nonce_valid


def generate_token_user(public_key,time_due=env.TOKEN_TIME):
    secret_key = env.SECRETE_KEY
    encoded_jwt = jwt.encode({"public_key":public_key,
                              "expire": int(time.time()) + time_due*60
                              }, secret_key,
                             algorithm="HS256")
    return encoded_jwt

def generate_onetime_token_user(public_key,time_due=env.TOKEN_TIME):
    secret_key = env.SECRETE_KEY
    nonce = str(uuid.uuid4())
    save_nonce_to_file(nonce)
    encoded_jwt = jwt.encode({"public_key":public_key,
                              "expire": int(time.time()) + time_due*60,
                              "nonce":nonce
                              }, secret_key,
                             algorithm="HS256")
    return encoded_jwt

def validate_token(request):
    try:
        token = request.headers.get('token')
    except:
        raise Exception(
            ErrorResponse(ResponseCode.MISSING_TOKEN, ResponseMessage.MISSING_TOKEN + str("errors")))
    secret_key = env.SECRETE_KEY
    decode = jwt.decode(token, secret_key,
                        algorithms=["HS256"])
    print(decode)
    if decode['expire'] <= int(time.time()):
        raise Exception(
            ErrorResponse(ResponseCode.INVALID_AUTHENTICATION, ResponseMessage.INVALID_AUTHENTICATION + str("errors")))
    return decode['public_key']

def validate_one_time_token(request):
    try:
        token = request.headers.get('token')
    except:
        raise Exception(
            ErrorResponse(ResponseCode.MISSING_TOKEN, ResponseMessage.MISSING_TOKEN + str("errors")))
    secret_key = env.SECRETE_KEY
    decode = jwt.decode(token, secret_key,
                        algorithms=["HS256"])
    if decode['expire'] <= int(time.time()):
        raise Exception(
            ErrorResponse(ResponseCode.INVALID_AUTHENTICATION, ResponseMessage.INVALID_AUTHENTICATION + str("errors")))
    if not is_nonce_valid(decode['nonce']):
        raise Exception(
            ErrorResponse(ResponseCode.INVALID_AUTHENTICATION, ResponseMessage.INVALID_AUTHENTICATION + str("errors")))
    is_nonce_valid(decode['nonce'])
    return decode['public_key']