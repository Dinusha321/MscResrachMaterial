from PIL import Image

def text_to_bin(text):
    binary = ''.join([format(ord(i), '08b') for i in text])
    return binary
def bin_to_text(binary):
    chars = [chr(int(binary[i:i+8], 2)) for i in range(0, len(binary), 8)]
    return ''.join(chars)
def encode_image_lsb2(image_path, secret_message, output_path):
    image = Image.open(image_path)
    image = image.convert("RGB")
    pixels = image.load()
    binary_secret_message = text_to_bin(secret_message) + '1111111111111110'
    binary_secret_message = [binary_secret_message[i:i+2] for i in range(0, len(binary_secret_message), 2)]

    data_index = 0
    for row in range(image.size[1]):
        for col in range(image.size[0]):
            if data_index < len(binary_secret_message):
                r, g, b = pixels[col, row]
                r = (r & ~3) | int(binary_secret_message[data_index], 2)
                pixels[col, row] = (r, g, b)

                data_index += 1
    image.save(output_path)
    print(f"Message hidden in {output_path}")

def decode_image_lsb2(image_path):
    image = Image.open(image_path)
    pixels = image.load()
    binary_message = ""
    for row in range(image.size[1]):
        for col in range(image.size[0]):
            r, g, b = pixels[col, row]
            binary_message += format(r & 3, '02b')
    end_signal = '1111111111111110'
    if end_signal in binary_message:
        binary_message = binary_message[:binary_message.index(end_signal)]
    return bin_to_text(binary_message)

# input_image_path = "images.png"
# output_image_path = "encoded_image_lsb2.png"
# secret_message = "This is a secret!"
# encode_image_lsb2(input_image_path, secret_message, output_image_path)
# decoded_message = decode_image_lsb2(output_image_path)
# print("Decoded message:", decoded_message)