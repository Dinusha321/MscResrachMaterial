from create_json import count_files_in_directory
import random
import string

def calculate_images_count():
    directory_path = f"images"
    num_files = count_files_in_directory(directory_path=directory_path)
    return num_files

def calculate_user_images_count(public_key):
    directory_path = f"nodes/{public_key}"
    num_files = count_files_in_directory(directory_path=directory_path)
    return num_files

def generate_random_string(length=20):
    characters = string.ascii_letters + string.digits
    random_string = ''.join(random.choice(characters) for _ in range(length))
    return random_string

def get_image_name():
    latest_number = f"00{calculate_images_count()+1}"
    latest_name = f"{generate_random_string()}_{latest_number}"
    print(latest_name)
    return latest_name

def get_user_image_name(public_key):
    latest_number = f"00{calculate_user_images_count(public_key=public_key)+1}"
    latest_name = f"{generate_random_string()}_{latest_number}"
    print(latest_name)
    return latest_name