from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed
from cryptography.hazmat.primitives import serialization
from mnemonic import Mnemonic
from hdwallet import HDWallet
import os
from ecdsa import SigningKey, SECP256k1
from hdwallet.symbols import ETH as SYMBOL
from authentication import generate_token_user
from make_directory import make_node, check_node_availability


def add_node():
    try:
        mnemo = Mnemonic("english")
        entropy = os.urandom(32)
        mnemonic_phrase = mnemo.to_mnemonic(entropy)
        seed = Mnemonic.to_seed(mnemonic_phrase).hex()
        hd_wallet = HDWallet(symbol=SYMBOL)
        hd_wallet.from_seed(seed)
        hd_wallet.from_path("m/44'/60'/0'/0/0")
        private_key = hd_wallet.private_key()
        public_key = hd_wallet.public_key()
        print("Mnemonic Phrase:", mnemonic_phrase)
        print("Derived Private Key:", private_key)
        print("Derived Public Key:", public_key)
        response = {
            "state" : True,
            "private_key": private_key,
            "phrase":mnemonic_phrase
        }
        make_node(public_key)
        return response
    except Exception as e:
        response = {
            'state': False,
            'error': str(e)
        }
        return response

def log_user_phrase(phrase):
    try:
        seed = Mnemonic.to_seed(phrase).hex()
        hd_wallet = HDWallet(symbol=SYMBOL)
        hd_wallet.from_seed(seed)
        hd_wallet.from_path("m/44'/60'/0'/0/0")
        private_key = hd_wallet.private_key()
        public_key = hd_wallet.public_key()
        print("Mnemonic Phrase:", phrase)
        print("Derived Private Key:", private_key)
        print("Derived Public Key:", public_key)
        response = {
            'state': check_node_availability(public_key),
            'public_key':public_key
        }
        return response
    except Exception as e:
        response = {
            'state': False,
            'error': str(e)
        }
        return response

def log_user_image(private_key):
    try:
        private_key_bytes = bytes.fromhex(private_key)
        signing_key = SigningKey.from_string(private_key_bytes, curve=SECP256k1)
        public_key_bytes = signing_key.verifying_key.to_string()
        compressed_public_key = b'\x02' + public_key_bytes[:32] if public_key_bytes[
                                                                       -1] % 2 == 0 else b'\x03' + public_key_bytes[:32]
        public_key = compressed_public_key.hex()
        print("Public Key (Uncompressed):", public_key)
        response = {
            'state': check_node_availability(public_key),
            'public_key':public_key
        }
        return response
    except Exception as e:
        response = {
            'state': False,
            'error': str(e)
        }
        return response


