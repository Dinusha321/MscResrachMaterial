import os
from flask import Flask,request, jsonify
from flask_cors import CORS , cross_origin
import env
from authentication import generate_token_user, validate_token
from check_image_availability import check_availability, convert_image_to_base64
from contract import add_node, log_user_image , log_user_phrase
from create_json import save_json, check_questions, get_questions
from data_encryption import encrypt_message, decrypt_message
from get_latest_image_name import get_image_name, get_user_image_name
from steganography import encode_image_lsb2, decode_image_lsb2

app = Flask(__name__)
CORS(app , resources={r"/":{"origins":"*"}})

@app.route("/")
def main():
    return "hello world"

@app.route("/home")
@cross_origin()
def home():
    return "First Page"

@app.route("/v1/images" , methods=["GET"])
@cross_origin()
def get_images():
    image_folder = 'images'  # Folder where images are stored
    image_files = os.listdir(image_folder)
    image_list = []
    for image_file in image_files:
        image_path = os.path.join(image_folder, image_file)
        image_data = convert_image_to_base64(image_path)
        image_list.append({
            'fileName': image_file,
            'data': image_data
        })

    return jsonify(image_list)

@app.route("/v1/get_questions" , methods=["POST"])
@cross_origin()
def get_questions_():
    body = request.json
    file_name = body['file_name'].split('.')[0]
    response = {
        "state":True,
        "questions":get_questions(file_name)
    }
    return response

@app.route("/v1/login" , methods=["POST"])
@cross_origin()
def login():
    body = request.json
    file_name = body['file_name']
    answers = body['answers']
    print(answers)
    key = answers[env.ENCRYPTION_KEY]
    result = check_questions(file_name.split('.')[0], answers=answers)
    if result:
        print(answers)
        image_folder = 'images'
        output_image_path = os.path.join(image_folder, file_name)
        encoded_private_key = decode_image_lsb2(output_image_path)
        private_key = decrypt_message(encoded_private_key, key)
        print(private_key)
        user_login_result = log_user_image(private_key)
        if user_login_result['state']:
            token = generate_token_user(public_key=user_login_result['public_key'])
            response = {
                'state': True,
                'token': token
            }
        else:
            response = {
                'state': False,
                'error': "incorrect image or birthday"
            }
    else:
        response = {
            'state': False,
            'error': "incorrect answers"
        }
    return response

@app.route("/v1/direct_login" , methods=["POST"])
@cross_origin()
def direct_login():
    body = request.json
    phrase = body['phrase']
    user_login_result = log_user_phrase(phrase=phrase)
    if user_login_result['state']:
        token = generate_token_user(public_key=user_login_result['public_key'])
        response = {
            'state': True,
            'token': token
        }
    else:
        response = {
            'state': False,
            'error': "incorrect image or birthday"
        }
    return response

@app.route("/v1/register", methods=["POST"])
@cross_origin()
def register():
    print("main")
    uploaded_file = request.files['image']
    # uploaded_file = True
    form_data = request.form.to_dict()
    print(form_data)
    encryption_key = form_data[env.ENCRYPTION_KEY]
    data = env.QUESTIONS
    for key in data:
        data[key] = encrypt_message(form_data[key], encryption_key)
    # data[env.ENCRYPTION_KEY] = request.form[env.ENCRYPTION_KEY]
    if uploaded_file:
        uploaded_file.save('uploaded.png')
        check_availability()
        result = add_node()
        if result['state']:
            private_key = result['private_key']
            phrase = result['phrase']
            encrypted_private_key = encrypt_message(private_key, encryption_key)
            latest_name = get_image_name()
            encode_image_lsb2(image_path="uploaded.png", secret_message=encrypted_private_key, output_path=f'images/{latest_name}.png')
            save_json(data, latest_name)
            response = {
                "state":True,
                'phrase':phrase,
                "message":"Registration Successful"
            }
            return response
        return result
    response = {
        "state": False,
        "message": "Registration Failed"
    }
    return response

@app.route("/v1/validate", methods=["GET"])
@cross_origin()
def validate_token_():
    response = validate_token(request)
    print(response)
    return {
        "state":True
    }

@app.route("/v1/add_data", methods=["POST"])
@cross_origin()
def add_data():
    response = validate_token(request)
    print(response)
    uploaded_file = request.files['image']
    uploaded_file.save(f'nodes/{response}/{get_user_image_name(response)}.png')
    return {
        "state":True
    }

@app.route("/v1/user_images" , methods=["GET"])
@cross_origin()
def get_user_images():
    response = validate_token(request)
    print(response)
    image_folder = f'nodes/{response}'  # Folder where images are stored
    image_files = os.listdir(image_folder)
    image_list = []
    for image_file in image_files:
        image_path = os.path.join(image_folder, image_file)
        image_data = convert_image_to_base64(image_path)
        image_list.append({
            'fileName': image_file,
            'data': image_data
        })

    return jsonify(image_list)

if __name__ == '__main__':
    app.debug = True
    app.run(host='localhost',port=5000)