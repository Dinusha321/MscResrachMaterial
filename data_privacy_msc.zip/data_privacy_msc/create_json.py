import ast
import os
import json
import random
from pathlib import Path

import env
from data_encryption import decrypt_message

# Example JSON data
data = {
    "name": "John Doe",
    "age": 30,
    "city": "New York",
    "hobbies": ["reading", "traveling", "swimming"]
}


def count_files_in_directory(directory_path):
    file_count = 0
    for _, _, files in os.walk(directory_path):
        file_count += len(files)

    return file_count

def save_json(data , public_key):
    directory_path = f"questions"
    block_name = f'{public_key}.json'
    file_path = os.path.join(directory_path, block_name)
    with open(file_path, 'w') as json_file:
        json.dump(data, json_file, indent=4)
    print(f"JSON data has been written to {file_path}")
    return

def get_questions(file_name):
    directory_path = f"questions"
    block_name = f'{file_name}.json'
    file_path = os.path.join(directory_path, block_name)
    with open(file_path, 'r') as file:
        data = json.load(file)
        print(type(data))
        # data = ast.literal_eval(data)
        print(data)
        return select_questions(data)

def select_questions(data):
    questions = list(data.keys())
    print(questions)
    num_elements = random.randint(3, 5)
    random_questions = random.sample(questions, num_elements)
    print(random_questions)
    random_questions.append(env.ENCRYPTION_KEY)
    questions_dict = {question: "" for question in random_questions}
    return questions_dict

def check_questions(file_name , answers):
    directory_path = f"questions"
    block_name = f'{file_name}.json'
    file_path = os.path.join(directory_path, block_name)
    with open(file_path, 'r') as file:
        data = json.load(file)
        print(type(data))
        accuracy = 0
        total = 0
        key = answers[env.ENCRYPTION_KEY]
        del answers[env.ENCRYPTION_KEY]
        for answer in answers:
            total+=1
            if decrypt_message(data[answer], key).lower() == answers[answer].lower():
                accuracy+=1
        if accuracy/total >= 1:
            return True
        return False

# save_json(data , "public_key")
# data = {
#     "a":1,
#     "b":2
# }
# select_questions(data)