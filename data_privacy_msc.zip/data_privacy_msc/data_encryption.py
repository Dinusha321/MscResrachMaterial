from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.fernet import Fernet
import base64
import os

def derive_key_from_password(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA512(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))

def encrypt_message(message, password):
    salt = os.urandom(16)
    key = derive_key_from_password(password, salt)
    cipher_suite = Fernet(key)
    encrypted_message = cipher_suite.encrypt(message.encode())
    encrypted_with_salt = salt + encrypted_message
    return base64.urlsafe_b64encode(encrypted_with_salt).decode()

def decrypt_message(encrypted_data, password):
    encrypted_with_salt = base64.urlsafe_b64decode(encrypted_data.encode())
    salt = encrypted_with_salt[:16]
    encrypted_message = encrypted_with_salt[16:]
    key = derive_key_from_password(password, salt)
    cipher_suite = Fernet(key)
    decrypted_message = cipher_suite.decrypt(encrypted_message).decode()
    return decrypted_message

# user_input_key = input("Enter the encryption key (password): ")
# message = input("Enter the message to encrypt: ")
# encrypted_message = encrypt_message(message, user_input_key)
# print("\nEncrypted message:", encrypted_message)
# user_input_key_for_decryption = input("\nEnter the same key to decrypt the message: ")
# try:
#     decrypted_message = decrypt_message(encrypted_message, user_input_key_for_decryption)
#     print("\nDecrypted message:", decrypted_message)
# except Exception as e:
#     print("Decryption failed:", e)